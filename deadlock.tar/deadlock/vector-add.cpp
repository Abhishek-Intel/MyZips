//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include <CL/sycl.hpp>

#include <array>
#include <iostream>
#include <iostream>

using namespace cl::sycl;

int calc()
{
    queue* device_queue = nullptr;

    const vector_class<platform>& platforms = platform::get_platforms();
    for (const platform& p : platforms)
    {
        const vector_class<device>& devices = p.get_devices();

        for (const device& d : devices)
        {
            const std::string& name = d.get_info<info::device::name>();
            if (name[0] == 'I')
            {
                std::cout << "set device" << std::endl;
                device_queue = new queue(d);
            }
        }
    }
       
    std::cout << "Device: "
            << device_queue->get_device().get_info<info::device::name>()
            << std::endl;
    const size_t ARRAY_SIZE = 100;
    range<2> num_items{ARRAY_SIZE / 2, ARRAY_SIZE / 2};

    buffer<cl_int, 1> buf2(new int[ARRAY_SIZE], ARRAY_SIZE);

    {
	    auto buf_w = buf2.get_access<access::mode::write>();
	    for (size_t i = 0; i < ARRAY_SIZE; i++)
        	buf_w[i] = i;
    }
/*
    device_queue->submit([&buf1, &buf2, &num_items](handler &cgh) {
        auto buf1_r = buf1.get_access<access::mode::read>(cgh);
        auto buf2_w = buf2.get_access<access::mode::write>(cgh);

        cgh.parallel_for<class empty_path_trace_tile_render_kernel>(num_items, [=](id<2> idx){
            size_t index = idx.get(0) * 10 + idx.get(1);
            buf2_w[index] = buf1_r[index];
        });
    });
    device_queue->wait();
*/ 

    auto buf_r = buf2.get_access<access::mode::read>();
    bool all_ok = true;
    for (size_t i = 0; i < ARRAY_SIZE; i++)
        if (buf_r[i] != i)
        {
            all_ok = false;
            fprintf(stderr, "Error on %zu: expect %zu but found %d\n", i, i, buf_r[i]);
        }
    if (all_ok)
        fprintf(stderr, "All ok\n");

	delete device_queue;
    return all_ok ? 0 : 1;
}

