#include "vector-add.h"

int main()
{
	return calc();
}
