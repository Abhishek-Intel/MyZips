#pragma once

int calc();
